# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class CancelInvoiceAction(models.TransientModel):
    _name = 'cancel.invoice.action'

    invoice_id = fields.Many2one(comodel_name="account.move")
    e_invoice_cancellation_reason = fields.Selection(string="Cancellation reason",
                                                     selection=[('Wrong invoice details', 'Wrong invoice details'),
                                                                ('Wrong buyer details', 'Wrong buyer details')],
                                                     required=True)

    def action_cancel_electronic_invoice(self):
        if self.invoice_id:
            self.invoice_id.cancel_e_invoice(self.e_invoice_cancellation_reason)
        return True