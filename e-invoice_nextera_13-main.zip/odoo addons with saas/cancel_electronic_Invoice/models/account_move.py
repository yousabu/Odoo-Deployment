# -*- coding: utf-8 -*-
import json
import logging
import requests
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'

    e_invoice_cancellation_reason = fields.Selection(string="Cancellation reason", copy=False,
                                                     selection=[('Wrong invoice details', 'Wrong invoice details'),
                                                                ('Wrong buyer details', 'Wrong buyer details')])

    def cancel_e_invoice(self, reason):
        self.e_invoice_cancellation_reason = reason
        self.button_draft()
        self.button_cancel()
        response, api = self.get_access_token()
        headers = {'Accept': "application/json", 'Content-Type': "application/json", 'Accept-Language': "en",
                   'Authorization': "Bearer " + response}
        data = {'status': 'cancelled', 'reason': reason}
        json_data = json.dumps(data)
        url = api + "/api/v1.0/documents/state/" + self.e_invoice_uuid + '/state'
        submition_response = requests.request("PUT", url, data=json_data.encode('utf-8'), headers=headers)
        # if submition_response.status_code == 200:
        if submition_response.status_code == 400:
            response_dict = submition_response.json()
            message = ""
            if response_dict.get('error', False) and response_dict['error'].get('code', False) \
                    and response_dict['error'].get('details', False):
                message += response_dict['error']['code']
                for detail in response_dict['error']['details']:
                    if detail.get('message', False):
                        message += '\n{}'.format(detail['message'])
            if message != "":
                raise ValidationError(message)
            else:
                raise ValidationError("Please review {} in e-invoice portal".format(self.name))
        elif submition_response.status_code == 403:
            raise ValidationError('You are trying to perform operation on a document not issued by them')

    def button_cancel(self):
        if self.move_type in (
                'out_invoice', 'out_refund') and self.e_invoice_uuid and not self.e_invoice_cancellation_reason:
            initial_date = fields.Datetime.now() - relativedelta(days=self.company_id.cancellation_allowed_period)
            if initial_date > self.e_invoice_receiving_date:
                raise ValidationError(
                    _('You can only cancel invoices submitted to e-invoice portal after {}').format(str(initial_date)))
            return {
                'name': _("Cancel E-invoice"),
                'view_mode': 'form',
                'view_id': self.env.ref('cancel_electronic_Invoice.view_cancel_electronic_invoice').id,
                'view_type': 'form',
                'res_model': 'cancel.invoice.action',
                'type': 'ir.actions.act_window',
                'target': 'new',
                'context': {'default_invoice_id': self.id, 'invoice_id': self.id, }
            }
        return super(AccountMove, self).button_cancel()

    def button_cancel_e_invoice(self):
        # self.button_draft()
        return self.button_cancel()
