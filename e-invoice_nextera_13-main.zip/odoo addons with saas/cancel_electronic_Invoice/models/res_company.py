# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class Company(models.Model):
    _inherit = 'res.company'

    cancellation_allowed_period = fields.Integer(string='Cancellation Allowance Period', default=3)
