# -*- coding: utf-8 -*-
{
    'name': 'Egyptian E-Invoice Cancellation',
    'version': '1',
    'summary': 'Egyptian E-Invoice Cancellation',
    'description': """
    """,
    'author': 'Mahmoud Elmenshawy',
    'website': "https://www.linkedin.com/in/mahmoudelmenshawy/",
    'category': 'Accounting',
    'depends': ['electronic_Invoice'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/res_company.xml',
        'views/account_move.xml',
        'wizards/cancel_e_invoices_action.xml',
    ],
    'installable': True,
    'application': True,
}
