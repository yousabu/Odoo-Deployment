# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class SendInvoiceAction(models.TransientModel):
    _name = 'send.invoice.action'

    def action_send_electronic_invoice(self):
        company_id = self.env.user.company_id
        active_ids = self._context.get('active_ids', [])
        if len(active_ids) > company_id.max_e_invoice_per_request:
            raise ValidationError(_('Please select at most {} invoices for company {}').
                                  format(company_id.max_e_invoice_per_request, company_id.name))
        all_invoice_ids = self.env['account.move'].browse(active_ids).filtered(
            lambda invoice: (not invoice.e_invoice_uuid or (
                    invoice.e_invoice_uuid and invoice.e_invoice_status == 'Invalid')) and
                            invoice.state in ('posted') and invoice.move_type in ('out_invoice'))
        if not all_invoice_ids:
            raise ValidationError(_('Please check invoice state to be posted or not sent once before'))
        invoice_ids_list = all_invoice_ids.ids
        max_e_invoice_per_batch = company_id.max_e_invoice_per_batch
        start_index = 0
        end_index = start_index + max_e_invoice_per_batch <= len(invoice_ids_list) and \
                    start_index + max_e_invoice_per_batch or len(invoice_ids_list)
        while True:
            invoice_ids = self.env['account.move'].browse(invoice_ids_list[start_index:end_index])
            invoice_ids.action_send_electronic_invoice()
            if end_index == len(invoice_ids_list):
                break
            else:
                start_index = end_index
                end_index = start_index + max_e_invoice_per_batch <= len(invoice_ids_list) and \
                            start_index + max_e_invoice_per_batch or len(invoice_ids_list)
