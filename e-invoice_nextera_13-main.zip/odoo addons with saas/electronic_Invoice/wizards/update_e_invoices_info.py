# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class GetInvoiceInfo(models.TransientModel):
    _name = 'update.invoice.info'

    def action_update_electronic_invoice(self):
        active_ids = self._context.get('active_ids', [])
        invoice_ids = self.env['account.move'].browse(active_ids).filtered(
            lambda invoice: invoice.e_invoice_uuid and invoice.printedElectronicInvoice and
                            invoice.state in ('posted') and invoice.move_type in ('out_invoice', 'out_refund'))
        if not invoice_ids:
            raise ValidationError(_('Please check invoice to be sent previously and link updated'))
        for invoice in invoice_ids:
            invoice.action_get_electronic_invoice_state()
