# -*- coding: utf-8 -*-
{
    'name': 'Egyptian E-Invoice',
    'version': '1',
    'summary': 'Egyptian E-Invoice',
    'description': """
    E-Invoicing is the solution of the Egyptian Tax Authority used by taxpayers to register their issued documents 
    with the Tax Authority, get notified on events related to document issuance.
    """,
    'author': 'Mahmoud Elmenshawy',
    'website': "https://www.linkedin.com/in/mahmoudelmenshawy/",
    'category': 'Accounting',
    'depends': ['base', 'account'],
    'data': [
        'data/data.xml',
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/account_tax.xml',
        'views/account_move.xml',
        'views/res_partner.xml',
        'views/res_company.xml',
        'views/product_views.xml',
        'wizards/send_e_invoices_action.xml',
        'wizards/get_e_invoices_info.xml',
        'wizards/update_e_invoices_info.xml',
    ],
    'installable': True,
    'application': True,
}
