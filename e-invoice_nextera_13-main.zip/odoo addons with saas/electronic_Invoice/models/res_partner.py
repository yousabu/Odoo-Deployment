# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class Partner(models.Model):
    _inherit = 'res.partner'

    regionCity = fields.Char(string='Region City')
    buildingNumber = fields.Char(string='Building Number')
    floor = fields.Char(string='Floor')
    room = fields.Char(string='Room')
    landmark = fields.Char(string='Landmark')
    additionalInformation = fields.Char(string='Additional Information')
    national_id = fields.Char(string='National Id')
    business_type = fields.Selection(string="Business Type", selection=[('P', 'Personal'), ('B', 'Business')],
                                     default='P')
