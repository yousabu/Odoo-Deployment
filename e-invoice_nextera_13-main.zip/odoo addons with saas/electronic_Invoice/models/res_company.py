# -*- coding: utf-8 -*-
import os
import json
from odoo import models, fields, api, _


class Company(models.Model):
    _inherit = 'res.company'

    def _get_selections(self):
        with open(os.path.join(os.path.dirname(__file__), '../data/ActivityCodes.json'), 'r') as f:
            distros_dict = json.load(f)
        list = []
        for code in distros_dict:
            code_new = code['code']
            value = code['Desc_en']
            sub_list = (code_new, value)
            list.append(sub_list)
        return list

    registration_name = fields.Char(string='Registration Name')
    governateE = fields.Char(string='Governate')
    regionCity = fields.Char(string='Region City')
    buildingNumber = fields.Char(string='Building Number')
    floor = fields.Char(string='Floor')
    room = fields.Char(string='Room')
    landmark = fields.Char(string='Landmark')
    additionalInformation = fields.Char(string='Additional Information')
    branchID = fields.Char(string='Branch Id')
    signature_url = fields.Char(string="Signature URL")
    token_label = fields.Char(string="Token Label", default='Egypt Trust')
    user_pin = fields.Char(string="Token User PIN")
    clientId = fields.Char(string='Client Id')
    clientSecret = fields.Char(string='Client Secret')
    configType = fields.Selection([('../data/EEI - UAT Env.postman_environment.json', 'UAT/PREPROD'),
                                   ('../data/EEI - SIT Env.postman_environment.json', 'SIT'),
                                   ('../data/EEI - PRD Env.postman_environment.json', 'PROD')],
                                  string='Platform',
                                  default='../data/EEI - UAT Env.postman_environment.json')
    invoiceVersion = fields.Selection([('0.9', '0.9'), ('1.0', '1.0')], string='Version', default='1.0')
    taxpayerActivityCode = fields.Selection(selection=lambda self: self._get_selections(),
                                            string="Activity Code", default='4610', copy=False)
    max_e_invoice_per_batch = fields.Integer(string="Max Invoice Numbers Per Batch", default=20)
    max_e_invoice_per_request = fields.Integer(string="Max Invoice Numbers Per Request", default=250)
