# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class Product(models.Model):
    _inherit = 'product.template'

    code_type = fields.Selection(string="Code Type", selection=[('EGS', 'EGS'), ('GS1', 'GS1'), ], default='GS1',
                                 tracking=True)
    e_invoice_code = fields.Char(string='Code', default='99999999', tracking=True)
