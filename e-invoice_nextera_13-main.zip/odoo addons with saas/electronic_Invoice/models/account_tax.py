# -*- coding: utf-8 -*-
import os
import json
import base64
import logging
import requests
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, AccessError

_logger = logging.getLogger(__name__)


class AccountTax(models.Model):
    _inherit = 'account.tax'

    def _get_tax_types_code(self):
        with open(os.path.join(os.path.dirname(__file__), '../data/TaxTypes.json'), 'r') as f:
            distros_dict = json.load(f)
        list = []
        for code in distros_dict:
            code_new = code['Code']
            value = code['Desc_en']
            sub_list = (code_new, value)
            list.append(sub_list)
        return list

    def _get_sub_tax_types_code(self):
        with open(os.path.join(os.path.dirname(__file__), '../data/TaxSubtypes.json'), 'r') as f:
            distros_dict = json.load(f)
        list = []
        for code in distros_dict:
            code_new = code['Code']
            value = code['Desc_en']
            sub_list = (code_new, value)
            list.append(sub_list)
        return list

    taxTypesCode = fields.Selection(selection=lambda self: self._get_tax_types_code(),
                                    string="E-Invoice Tax Type", default="T1")
    subTaxTypesCode = fields.Selection(selection=_get_sub_tax_types_code, string="E-Invoice SubTax Type",
                                       default="V009")
