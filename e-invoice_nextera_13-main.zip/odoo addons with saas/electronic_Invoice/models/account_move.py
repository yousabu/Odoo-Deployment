# -*- coding: utf-8 -*-
import os
import json
import base64
import logging
import requests
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, AccessError

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'

    def _get_selections(self):
        with open(os.path.join(os.path.dirname(__file__), '../data/ActivityCodes.json'), 'r') as f:
            distros_dict = json.load(f)
        list = []
        for code in distros_dict:
            code_new = code['code']
            value = code['Desc_en']
            sub_list = (code_new, value)
            list.append(sub_list)
        return list

    taxpayerActivityCode = fields.Selection(selection=lambda self: self._get_selections(),
                                            string="Activity Code", copy=False,
                                            default=lambda self: self.env.company.taxpayerActivityCode)
    printedElectronicInvoice = fields.Char(string='ETA Link', readonly=False, copy=False)
    e_invoice_uuid = fields.Char(string='ETA ID', readonly=False, copy=False, index=True)
    e_invoice_submission_date = fields.Datetime(string='Submission Date', readonly=False, copy=False, index=True)
    e_invoice_status = fields.Char(string="ETA Status", readonly=False, copy=False, index=True)
    e_invoice_invalid_reason = fields.Text(string="ETA Invalid Reason", readonly=False, copy=False)
    e_invoice_receiving_date = fields.Datetime(string='ETA Receiving Date', readonly=False, copy=False, index=True)
    e_invoice_longId = fields.Char(string="LongId", readonly=False, copy=False)
    e_invoice_hashKey = fields.Char(string="HashKey", readonly=False, copy=False)
    e_invoice_submissionId = fields.Char(string="SubmissionId", readonly=False, copy=False)

    def get_e_invoice_config(self):
        company_id = self.company_id
        platform = company_id.configType
        with open(os.path.join(os.path.dirname(__file__), platform), 'r') as f:
            distros_dict = json.load(f)
        url = distros_dict['values'][1]['value']
        api = distros_dict['values'][0]['value']

        clientId = company_id.clientId
        clientSecret = company_id.clientSecret
        invoiceVersion = company_id.invoiceVersion
        if not clientId or not clientSecret or not invoiceVersion or not platform:
            raise ValidationError(_('Please review company profile E-invoice setting'))
        return url, api, clientId, clientSecret, invoiceVersion

    @api.model
    def get_issuer_data(self, issuer):
        return {
            "address": {
                "branchID": issuer.branchID and issuer.branchID or "0",
                "country": "EG",
                "governate": issuer.governateE and issuer.governateE or "Cairo",
                "regionCity": issuer.city and issuer.city or "Region City",
                "street": issuer.street and issuer.street or "street1",
                "buildingNumber": issuer.buildingNumber and issuer.buildingNumber or "0",
                "postalCode": issuer.zip and issuer.zip or "12345",
                "floor": issuer.floor and issuer.floor or "0",
                "room": issuer.room and issuer.room or "0",
                "landmark": issuer.landmark and issuer.landmark or "",
                "additionalInformation": issuer.additionalInformation and issuer.additionalInformation or ""
            },
            "type": "B",
            "id": issuer.vat and issuer.vat or "",
            "name": issuer.registration_name and str(issuer.registration_name) or 'company name'
        }

    @api.model
    def get_reciever_data(self, partner_id):
        if partner_id.business_type == 'B' and not partner_id.vat:
            raise ValidationError(_("Customer {} vat number must be defined"))
        return {
            "address": {
                "country": "EG",
                "governate": partner_id.city and partner_id.city or "Cairo",
                "regionCity": partner_id.regionCity and partner_id.regionCity or "Region City",
                "street": partner_id.street and partner_id.street or "street",
                "buildingNumber": partner_id.buildingNumber and partner_id.buildingNumber or "0",
                "postalCode": str(partner_id.zip) and partner_id.zip or "123456",
                "floor": str(partner_id.floor) and partner_id.floor or "0",
                "room": str(partner_id.room) and partner_id.room or "0",
                "landmark": partner_id.landmark and partner_id.landmark or "",
                "additionalInformation": partner_id.additionalInformation and partner_id.additionalInformation or ""
            },
            "type": partner_id.business_type and str(partner_id.business_type) or 'P',
            "id": partner_id.vat and str(partner_id.vat) or '',
            "name": partner_id.name and str(partner_id.name) or "Cash Customer"
        }

    def get_payment_data(self):
        return {
            "bankName": "",
            "bankAddress": "",
            "bankAccountNo": "",
            "bankAccountIBAN": "",
            "swiftCode": "",
            "terms": ""
        }

    def get_delivery_data(self):
        return {
            "approach": "",
            "packaging": "",
            "dateValidity": "",
            "exportPort": "",
            "countryOfOrigin": "EG",
            "grossWeight": 0,
            "netWeight": 0,
            "terms": ""
        }

    @api.model
    def get_invoice_lines(self, invoice_line_ids, currency_id, currency_rate):
        invalid_lines = invoice_line_ids.filtered(lambda line: not line.product_id.code_type or
                                                               not line.product_id.e_invoice_code)
        if invalid_lines:
            raise ValidationError(_('Please check code type and code for products: {}\n Invoice: "{}" \n').format(
                invalid_lines.mapped('product_id.name'), invoice_line_ids.move_id.name))
        total_discount = 0
        total_salesTotalAmount = 0
        total_tax_amount = 0
        lines_list = []
        used_taxes_for_totals = []
        for line in invoice_line_ids:
            quantity = line.quantity and line.quantity or 1
            amountEGP = round(line.price_unit * quantity * currency_rate, 5)
            rate = line.discount and line.discount or 0
            discount_amount = round(((rate / 100.0) * amountEGP), 5)
            total_salesTotalAmount += amountEGP
            total_discount += discount_amount

            lines_data_dict = {
                "description": line.product_id.name and line.product_id.name or line.name,
                "itemType": line.product_id.code_type and line.product_id.code_type or 'GS1',
                "itemCode": line.product_id.e_invoice_code and line.product_id.e_invoice_code or line.product_id.id,
                "internalCode": line.product_id.e_invoice_code and line.product_id.e_invoice_code or line.product_id.id,
                "unitType": line.unitType and line.unitType or "EA",
                "quantity": line.quantity,
                "unitValue": {
                    "currencySold": currency_id.name,
                    "amountSold": currency_id.name != 'EGP' and round(line.price_unit, 5) or 0.0,
                    "currencyExchangeRate": currency_id.name != 'EGP' and currency_rate or 0.0,
                    "amountEGP": round(line.price_unit, 5) * currency_rate
                },
                "salesTotal": amountEGP,
                "valueDifference": 0,
                "totalTaxableFees": 0,
                "discount": {
                    "rate": round(rate, 5),
                    "amount": discount_amount,
                },
                "netTotal": round(amountEGP - discount_amount, 5),
                "itemsDiscount": 0}
            tax_ids_lines = []
            line_total_tax_amount = 0.0
            for tax_id in line.tax_ids:
                tax_rate = tax_id.amount
                tax_amount = tax_rate * (amountEGP - discount_amount)
                tax_amount = round(tax_amount, 3) if line.tax_ids else 0
                tax_dict = {
                    "taxType": tax_id.taxTypesCode if tax_id.taxTypesCode else "T1",
                    "subType": tax_id.subTaxTypesCode if tax_id.subTaxTypesCode else "V009",
                    "rate": abs(round(tax_rate, 2)),
                    "amount": abs(round(tax_amount / 100, 5)),
                }
                tax_ids_lines.append(tax_dict)
                used_taxes_for_totals.append(tax_dict)
                line_total_tax_amount += round(tax_amount / 100, 5)
                total_tax_amount += round(tax_amount / 100, 5)
            lines_data_dict['taxableItems'] = tax_ids_lines
            lines_data_dict['total'] = round(line_total_tax_amount + amountEGP - discount_amount, 5)
            lines_list.append(lines_data_dict)
        return lines_list, total_salesTotalAmount, total_discount, round(total_tax_amount, 5), used_taxes_for_totals

    @api.model
    def get_invoice_taxes(self, used_taxes_for_totals=[]):
        result = []
        grouped_taxes = {}
        for tax_dict in used_taxes_for_totals:
            if tax_dict.get('taxType', False):
                if grouped_taxes.get(tax_dict['taxType'], False):
                    grouped_taxes[tax_dict['taxType']] += tax_dict.get('amount', 0)
                else:
                    grouped_taxes[tax_dict['taxType']] = tax_dict.get('amount', 0)
        for tax in grouped_taxes:
            result.append({'taxType': tax, 'amount': grouped_taxes[tax]})
        return result

    @api.model
    def get_signature_data(self, document_data, company_id):
        document = json.loads(document_data)
        new_str = fromObjecttoUpperCaseString(document)
        error_message = 'Can not connect signature server, please ask you admin to fix it'
        try:
            if company_id.signature_url:
                url = company_id.signature_url
                signature_response = requests.get(url + '/sign', verify=False, params={"data": new_str,
                                                                                       'user_pin': company_id.user_pin,
                                                                                       'token_label': company_id.token_label})
            else:
                raise ValidationError(_('Please configure signature server at company profile'))
            if signature_response.status_code == 201:
                error_message = signature_response.content.decode('utf-8')
                raise ValidationError(_(error_message))
        except:
            raise ValidationError(_(error_message))
        return [{
            "signatureType": "I",
            "value": signature_response.text
        }]

    @api.model
    def get_signature_data_encrypt(self, new_str, company_id):
        error_message = 'Can not connect signature server, please ask you admin to fix it'
        try:
            if company_id.signature_url:
                url = company_id.signature_url
                signature_response = requests.get(url + '/sign', verify=False, params={"data": new_str,
                                                                                       'user_pin': company_id.user_pin,
                                                                                       'token_label': company_id.token_label})
            else:
                raise ValidationError(_('Please configure signature server at company profile'))
            if signature_response.status_code == 201:
                error_message = signature_response.content.decode('utf-8')
                raise ValidationError(_(error_message))
        except:
            raise ValidationError(_(error_message))
        return [{
            "signatureType": "I",
            "value": signature_response.text
        }]

    def action_send_electronic_invoice(self):
        _logger.info('========================= START action_send_electronic_invoice =========================')
        config = self.get_e_invoice_config()
        url = config[0]
        api = config[1]
        clientId = config[2]
        clientSecret = config[3]
        invoiceVersion = config[4]
        egp_currency = self.env.ref('base.EGP')
        egp_rate = egp_currency.rate
        if egp_rate == 0:
            raise ValidationError(_('Please Check EGP currency rate, as it can not be zero'))
        documents = []
        companies_list = []
        issuer_data_per_company = {}
        for company_id in self.mapped('company_id'):
            issuer_data_per_company[company_id] = self.get_issuer_data(company_id)
        for invoice in self.filtered(lambda invoice: invoice.move_type in ('out_invoice', 'out_refund')):
            if invoice.e_invoice_uuid and invoice.e_invoice_status != 'Invalid':
                raise ValidationError(_('Invoice {} sent once before').format(invoice.name))
            currency_id = invoice.currency_id
            invoice_currency_rate = currency_id.rate
            if invoice_currency_rate == 0:
                raise ValidationError(
                    _('Please Check {} currency rate, as it can not be zero').format(currency_id.name))
            currency_rate = currency_id.name != 'EGP' and round(egp_rate / invoice_currency_rate, 5) or 1
            dateTimeIssued = str(invoice.invoice_date) + "T00:00:00Z"
            get_invoice_lines_data = self.get_invoice_lines(invoice.invoice_line_ids, currency_id, currency_rate),
            totalSalesAmount = get_invoice_lines_data[0][1]
            totalDiscountAmount = get_invoice_lines_data[0][2]
            total_tax_amount = get_invoice_lines_data[0][3]
            used_taxes_for_totals = get_invoice_lines_data[0][4]
            netAmount = totalSalesAmount - totalDiscountAmount
            totalAmount = round(netAmount + total_tax_amount, 3)
            partner_id = invoice.partner_id
            documentType = (invoice.move_type == 'out_invoice') and 'I' or 'C'
            invoice_data = {
                'issuer': issuer_data_per_company[invoice.company_id],
                'receiver': self.get_reciever_data(partner_id),
                "documentType": documentType,
                "documentTypeVersion": str(invoiceVersion),
                "dateTimeIssued": dateTimeIssued,
                "taxpayerActivityCode": str(
                    invoice.taxpayerActivityCode) and invoice.taxpayerActivityCode or "4610",
                "internalID": invoice.name and str(invoice.name) or str(invoice.id),
                "purchaseOrderReference": invoice.payment_reference and str(invoice.payment_reference) or str(
                    invoice.name),
                "purchaseOrderDescription": "",
                "salesOrderReference": invoice.ref and invoice.ref or "",
                "salesOrderDescription": "Taxable products",
                "proformaInvoiceNumber": "",
                "payment": invoice.get_payment_data(),
                "delivery": invoice.get_delivery_data(),
                "invoiceLines": get_invoice_lines_data[0][0],
                "totalSalesAmount": round(totalSalesAmount, 5),
                "totalDiscountAmount": round(totalDiscountAmount, 5),
                "netAmount": round(netAmount, 5),
                "taxTotals": self.get_invoice_taxes(used_taxes_for_totals),
                "extraDiscountAmount": 0,
                "totalItemsDiscountAmount": 0,
                "totalAmount": round(totalAmount, 5)
            }

            companies_list.append(invoice.company_id)
            ############# V 1.0
            documents.append(invoice_data)
            if invoiceVersion == '1.0':
                json_docs = json.dumps(documents, indent=2, ensure_ascii=False)
                error_message = ''
                str_list = []
                try:
                    encrypt_result = requests.get(
                        self.env.ref('electronic_Invoice.default_encryption_url').value + '/encrypt',
                        verify=False,
                        params={"data": json_docs.encode('utf-8')})
                    if encrypt_result.status_code == 200:
                        str_list = encrypt_result.json()
                    else:
                        error_message = encrypt_result.text
                except:
                    raise ValidationError(
                        _('''Some thing went wrong while encrypting data .. please contact support'''))
                finally:
                    if error_message != '':
                        raise ValidationError(_(error_message))
                count = 0
                if str_list:
                    for invoice in documents:
                        signature_data = self.get_signature_data_encrypt(str_list[count], companies_list[count])
                        invoice['signatures'] = signature_data
                        count += 1
        final_data_dict = {'documents': documents}
        json_documents = json.dumps(final_data_dict, indent=2, ensure_ascii=False)
        # Call external Api to get token from gov portal
        headers = {'content-type': "application/x-www-form-urlencoded", 'cache-control': "no-cache"}
        payload = {
            'grant_type': 'client_credentials',
            'client_id': clientId,
            'client_secret': clientSecret,
            'scope': 'InvoicingAPI',
        }
        # Submitting data to e-invoice portal
        r = requests.request("POST", url + "/connect/token", data=payload, headers=headers, verify=False)
        response = r.json()['access_token']
        headers = {'Content-Type': "application/json", 'cache-control': "no-cache",
                   'Authorization': "Bearer " + response}
        submissions_url = "/api/v1.0/documentsubmissions"
        submition_response = requests.request("POST", api + submissions_url, data=json_documents.encode('utf-8'),
                                              headers=headers, verify=False)
        message = ""
        if submition_response.json().get('acceptedDocuments', False):
            for acceptedDocument in submition_response.json().get('acceptedDocuments'):
                invoice_id = self.env['account.move'].search([('name', '=', acceptedDocument['internalId'])], limit=1)
                invoice_id.update({'e_invoice_uuid': acceptedDocument['uuid'],
                                   'e_invoice_submission_date': fields.Datetime.now(),
                                   'e_invoice_status': False,
                                   'e_invoice_invalid_reason': False,
                                   'e_invoice_receiving_date': False,
                                   'printedElectronicInvoice': False,
                                   'e_invoice_longId': acceptedDocument['longId'],
                                   'e_invoice_hashKey': acceptedDocument['hashKey'],
                                   'e_invoice_submissionId': submition_response.json()['submissionId']})
        elif submition_response.json().get('error', False) and submition_response.json()['error'].get('code', False) \
                and submition_response.json()['error'].get('details', False):
            for detail in submition_response.json()['error']['details']:
                if detail.get('message', False):
                    message += '\n{}'.format(detail['message'])

        self._cr.commit()
        all_response_dict = submition_response.json()
        if 'rejectedDocuments' in all_response_dict:
            for response_dict in all_response_dict['rejectedDocuments']:
                if response_dict.get('error', False) and response_dict['error'].get('code', False) and response_dict[
                    'error'].get('details', False):
                    message += response_dict['internalId']
                    for detail in response_dict['error']['details']:
                        if detail.get('message', False):
                            message += '\n{}'.format(detail['message'])
        if message != "":
            raise ValidationError(message)
        _logger.info('========================= END action_send_electronic_invoice =========================')

    def get_access_token(self):
        config = self.get_e_invoice_config()
        url = config[0]
        api = config[1]
        clientId = config[2]
        clientSecret = config[3]

        headers = {'content-type': "application/x-www-form-urlencoded", 'cache-control': "no-cache"}
        payload = {
            'grant_type': 'client_credentials',
            'client_id': clientId,
            'client_secret': clientSecret,
            'scope': 'InvoicingAPI',
        }
        r = requests.request("POST", url + "/connect/token", data=payload, headers=headers, verify=False)
        response = r.json().get('access_token', False)
        return response, api

    def get_document_details(self):
        response, api = self.get_access_token()
        headers = {'Content-Type': "application/json", 'cache-control': "no-cache",
                   'Authorization': "Bearer " + response}
        url = api + "/api/v1/documents/" + self.e_invoice_uuid + "/details"
        response = requests.request("GET", url, headers=headers, verify=False)
        return response

    @api.model
    def get_invalid_reason(self, status, document_details):
        e_invoice_invalid_reason = ''
        if status == 'Invalid' and document_details.get('validationResults', False):
            if document_details['validationResults'].get('validationSteps', False) \
                    and type(document_details['validationResults']['validationSteps']) is list:
                for step in document_details['validationResults']['validationSteps']:
                    if step.get('status', False) == 'Invalid' and type(step['error']) is dict:
                        if step['error'].get('innerError', False) and type(step['error']['innerError']) is list:
                            for error_item in step['error']['innerError']:
                                if error_item.get('error', False):
                                    e_invoice_invalid_reason += error_item.get('error') + '\n'
        return e_invoice_invalid_reason

    def action_get_electronic_invoice(self):
        document_details = self.get_document_details()
        if document_details.json():
            document_details = document_details.json()
            status = document_details.get('status', False)
            e_invoice_invalid_reason = self.get_invalid_reason(status, document_details)
            dateTimeRecevied = document_details.get('dateTimeRecevied', False)
            if dateTimeRecevied:
                dateTimeRecevied = dateTimeRecevied.replace('T', ' ')
                dateTimeRecevied = dateTimeRecevied.split('.')[0]
            publicUrl = document_details.get('publicUrl', False)
            if publicUrl and status and dateTimeRecevied:
                self.update({
                    'printedElectronicInvoice': '<a href="{} target="_blank" aria-label="Download" title="Download">ETA Document Link</a>'.format(
                        publicUrl),
                    'e_invoice_invalid_reason': e_invoice_invalid_reason != '' and e_invoice_invalid_reason or False,
                    'e_invoice_receiving_date': dateTimeRecevied,
                    'e_invoice_status': status})
            else:
                raise ValidationError(_('Please try again later'))

    def action_get_electronic_invoice_state(self):
        document_details = self.get_document_details()
        if document_details.json():
            document_details = document_details.json()
            status = document_details.get('status', False)
            e_invoice_invalid_reason = self.get_invalid_reason(status, document_details)

            if status:
                self.update({'e_invoice_status': status,
                             'e_invoice_invalid_reason': e_invoice_invalid_reason != '' and e_invoice_invalid_reason or False,
                             })
            else:
                raise ValidationError(_('Please try again later'))


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    unitType = fields.Selection([
        ('2Z', 'Millivolt ( mV )'),
        ('4K', 'Milliampere ( mA )'),
        ('4O', 'Microfarad ( microF )'),
        ('A87', 'Gigaohm ( GOhm )'),
        ('A93', 'Gram/Cubic meter ( g/m3 )'),
        ('A94', 'Gram/cubic centimeter ( g/cm3 )'),
        ('AMP', 'Ampere ( A )'),
        ('ANN', 'Years ( yr )'),
        ('B22', 'Kiloampere ( kA )'),
        ('B49', 'Kiloohm ( kOhm )'),
        ('B75', 'Megohm ( MOhm )'),
        ('B78', 'Megavolt ( MV )'),
        ('B84', 'Microampere ( microA )'),
        ('BAR', 'bar ( bar )'),
        ('BG', 'Bag ( Bag )'),
        ('BO', 'Bottle ( Bt. )'),
        ('C10', 'Millifarad ( mF )'),
        ('C39', 'Nanoampere ( nA )'),
        ('C41', 'Nanofarad ( nF )'),
        ('C45', 'Nanometer ( nm )'),
        ('C62', 'Activity unit ( AU )'),
        ('CA', 'Canister ( Can )'),
        ('CMK', 'Square centimeter ( cm2 )'),
        ('CMQ', 'Cubic centimeter ( cm3 )'),
        ('CMT', 'Centimeter ( cm )'),
        ('CS', 'Case ( Case )'),
        ('CT', 'Carton ( Car )'),
        ('CTL', 'Centiliter ( Cl )'),
        ('D10', 'Siemens per meter ( S/m )'),
        ('D33', 'Tesla ( D )'),
        ('D41', 'Ton/Cubic meter ( t/m3 )'),
        ('DAY', 'Days ( d )'),
        ('EA', 'each (ST) ( ST )'),
        ('FAR', 'Farad ( F )'),
        ('FOT', 'Foot ( Foot )'),
        ('FTK', 'Square foot ( ft2 )'),
        ('FTQ', 'Cubic foot ( ft3 )'),
        ('G42', 'Microsiemens per centimeter ( microS/cm )'),
        ('GL', 'Gram/liter ( g/l )'),
        ('GLL', 'gallon ( gal )'),
        ('GM', 'Gram/square meter ( g/m2 )'),
        ('GRM', 'Gram ( g )'),
        ('H63', 'Milligram/Square centimeter ( mg/cm2 )'),
        ('HLT', 'Hectoliter ( hl )'),
        ('HTZ', 'Hertz (1/second) ( Hz )'),
        ('HUR', 'Hours ( hrs )'),
        ('IE', 'Number of Persons ( PRS )'),
        ('INH', 'Inch ( “” )'),
        ('INK', 'Square inch ( Inch2 )'),
        ('KGM', 'Kilogram ( KG )'),
        ('KHZ', 'Kilohertz ( kHz )'),
        ('KMH', 'Kilometer/hour ( km/h )'),
        ('KMK', 'Square kilometer ( km2 )'),
        ('KMQ', 'Kilogram/cubic meter ( kg/m3 )'),
        ('KMT', 'Kilometer ( km )'),
        ('KSM', 'Kilogram/Square meter ( kg/m2 )'),
        ('KVT', 'Kilovolt ( kV )'),
        ('KWT', 'Kilowatt ( KW )'),
        ('LTR', 'Liter ( l )'),
        ('M', 'Meter ( m )'),
        ('MAW', 'Megawatt ( VA )'),
        ('MGM', 'Milligram ( mg )'),
        ('MHZ', 'Megahertz ( MHz )'),
        ('MIN', 'Minute ( min )'),
        ('MMK', 'Square millimeter ( mm2 )'),
        ('MMQ', 'Cubic millimeter ( mm3 )'),
        ('MMT', 'Millimeter ( mm )'),
        ('MON', 'Months ( Months )'),
        ('MTK', 'Square meter ( m2 )'),
        ('MTQ', 'Cubic meter ( m3 )'),
        ('OHM', 'Ohm ( Ohm )'),
        ('ONZ', 'Ounce ( oz )'),
        ('PAL', 'Pascal ( Pa )'),
        ('PF', 'Pallet ( PAL )'),
        ('PK', 'Pack ( PAK )'),
        ('SH', 'Shrink ( Shrink )'),
        ('SMI', 'Mile ( mile )'),
        ('TNE', 'Tonne ( t )'),
        ('VLT', 'Volt ( V )'),
        ('WEE', 'Weeks ( Weeks )'),
        ('WTT', 'Watt ( W )'),
        ('X03', 'Meter/Hour ( m/h )'),
        ('YDQ', 'Cubic yard ( yd3 )'),
        ('YRD', 'Yards ( yd )'), ], string='E-Invoice Unit Type', default="EA")
