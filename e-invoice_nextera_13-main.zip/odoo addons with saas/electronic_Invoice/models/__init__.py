# -*- coding: utf-8 -*-
from . import account_tax
from . import res_company
from . import account_move
from . import res_partner
from . import product
