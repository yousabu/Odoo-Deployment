# script Author: Mahmoud Elmenshawy

import json
import flask
from flask import request
import logging

logging.basicConfig(filename='flask-5001.log', level=logging.WARNING)
app = flask.Flask(__name__)

app.config["DEBUG"] = True


def fromObjectTo(old_value, new_str):
    for old_key in old_value:
        new_value = old_value[old_key]
        if type(new_value) is dict:
            new_new_key = old_key.upper()
            new_str += '"' + new_new_key + '"'
            for the_value in new_value:
                new_new_valu = new_value[the_value]
                new_new_new_key = the_value.upper()
                new_str += '"' + new_new_new_key + '"'
                if type(new_new_valu) is dict:
                    for pre_value in new_new_valu:
                        pre_new_valu = new_new_valu[pre_value]
                        pre_new_new_key = pre_value.upper()
                        new_str += '"' + pre_new_new_key + '"'
                        new_value_s = str(pre_new_valu)
                        new_str += '"' + new_value_s + '"'
                elif type(new_new_valu) is list:
                    new_new_new_key = the_value.upper()
                    new_str += '"' + new_new_new_key + '"'
                    fromObjectTo(new_new_valu, new_str)
                else:
                    new_value_s = str(new_new_valu)
                    new_str += '"' + new_value_s + '"'
        elif type(new_value) is list:
            for new_list_value in new_value:
                pre_key = old_key.upper()
                new_str += '"' + pre_key + '"'
                for the_value in new_list_value:
                    new_new_valu = new_list_value[the_value]
                    new_new_new_key = the_value.upper()
                    new_str += '"' + new_new_new_key + '"'
                    if type(new_new_valu) is dict:
                        for pre_value in new_new_valu:
                            pre_new_valu = new_new_valu[pre_value]
                            pre_new_new_key = pre_value.upper()
                            new_str += '"' + pre_new_new_key + '"'
                            new_value_s = str(pre_new_valu)
                            new_str += '"' + new_value_s + '"'
                    elif type(new_new_valu) is list:
                        new_new_new_key = the_value.upper()
                        new_str += '"' + new_new_new_key + '"'
                        fromObjectTo(new_new_valu, new_str)
                    else:
                        new_value_s = str(new_new_valu)
                        new_str += '"' + new_value_s + '"'
        else:
            new_new_key = old_key.upper()
            new_str += '"' + new_new_key + '"'
            new_new_value = str(new_value)
            new_str += '"' + new_new_value + '"'
    return new_str


def fromObjecttoUpperCaseString(document):
    new_str = ''
    for key in document:
        value = document[key]
        if type(value) is dict:
            new_key = key.upper()
            new_str += '"' + new_key + '"'
            new_str = fromObjectTo(value, new_str)
        elif type(value) is list:
            pre_key = key.upper()
            new_str += '"' + pre_key + '"'
            for new_list_value in value:
                pre_key = key.upper()
                new_str += '"' + pre_key + '"'
                for the_value in new_list_value:
                    new_new_valu = new_list_value[the_value]
                    new_new_new_key = the_value.upper()
                    new_str += '"' + new_new_new_key + '"'
                    if type(new_new_valu) is dict:
                        for pre_value in new_new_valu:
                            pre_new_valu = new_new_valu[pre_value]
                            pre_new_new_key = pre_value.upper()
                            new_str += '"' + pre_new_new_key + '"'
                            new_value = str(pre_new_valu)
                            new_str += '"' + new_value + '"'
                    elif type(new_new_valu) is list:
                        for ore_new_new_valu in new_new_valu:
                            new_new_new_key = the_value.upper()
                            new_str += '"' + new_new_new_key + '"'
                            new_str = fromObjectTo(ore_new_new_valu, new_str)
                    else:
                        new_value = str(new_new_valu)
                        new_str += '"' + new_value + '"'
        else:
            new_key = key.upper()
            new_str += '"' + new_key + '"'
            new_value = str(value)
            new_str += '"' + new_value + '"'
    return new_str


@app.route('/encrypt', methods=['GET'])
def home():
    documents = request.args.get('data')
    result = []
    for invoice in json.loads(documents):
        result.append(fromObjecttoUpperCaseString(invoice))
    return json.dumps(result), 200
    # return '''Your E-invoice module is not approved from Mahmoud Elmenshawy.
    # Please contact him at "+201144139842" to solve that issue''', 201


app.run(host='0.0.0.0', port=5001)
